# Issue #9 — Desenvolvimento Web — Preparação da publicação

Este ZIP contém somente os arquivos separados para esta atividade. Os cinco pacotes se complementam e devem ser aplicados no mesmo repositório existente. Ordem sugerida: #5, #8, #11, #9, #12. Não substituem os documentos anteriores do projeto.

## Como usar

1. Extraia o ZIP.
2. Abra a pasta arquivos-do-repositorio.
3. Copie o CONTEÚDO dela para a raiz do seu repositório, mantendo as pastas 2026-2, .github e tests quando presentes. Atualize os arquivos de mesmo caminho.
4. Faça o commit desses arquivos antes de copiar o pacote seguinte.
5. Este LEIA-PRIMEIRO.md é uma orientação de entrega, não precisa ir para o repositório. Não envie o ZIP como substituto dos arquivos abertos.

Pelo site do GitHub: na raiz do repositório, use Add file → Upload files e arraste o conteúdo de arquivos-do-repositorio, preservando a estrutura. Se o seletor ocultar .github, confira a configuração do explorador ou crie .github/workflows/pages.yml pelo editor do GitHub.

## Mensagem sugerida do commit

ci: prepara publicação do protótipo no GitHub Pages — refs #9

O texto refs #9 vincula o commit à issue sem encerrá-la automaticamente. Depois da validação, marque os itens do checklist e registre os links dos arquivos antes de fechar a issue.

## Próximo passo

Este pacote configura a publicação. A issue só fica concluída depois de ativar GitHub Pages, publicar, abrir a URL real e inseri-la no topo do README. Siga 2026-2/desenvolvimento-web/publicacao.md.

## Arquivos deste pacote

- .github/workflows/pages.yml
- 2026-2/desenvolvimento-web/publicacao.md
